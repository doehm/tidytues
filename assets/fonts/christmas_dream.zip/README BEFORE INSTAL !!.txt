ATTENTION !!

By downloading and installing this font, you are agree that the only font you install and you download is the "FOR PERSONAL USE" font that is "Non-Commercial".
And if you use the font on a "Commercial", there will be consequences for paying according to the license you are using.


Full License Here :
https://www.creativefabrica.com/product/christmas-dream-3/ref/379016/
https://creativemarket.com/HATFSTUDIO/91583117-Christmas-Dream

For Donation Paypal : hatftype@gmail.com

1. This font is ONLY FOR PERSONAL USE.
2. NO COMMERCIAL USE ALLOWED.
3. You are REQUIRES A LICENSE for PROMOTIONAL or COMMERCIAL USE.
4. CONTACT ME before any Promotional or Commercial Use.


Support email:
hatftype@gmail.com

Thanks